package com.kuryehesabim.app.ui.add

import android.app.TimePickerDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.google.android.material.snackbar.Snackbar
import com.kuryehesabim.app.MainActivity
import com.kuryehesabim.app.data.entity.WorkEntry
import com.kuryehesabim.app.databinding.FragmentAddEntryBinding
import com.kuryehesabim.app.util.Constants
import com.kuryehesabim.app.util.DateUtils
import kotlinx.coroutines.launch
import java.util.*

class AddEntryFragment : Fragment() {

    private var _binding: FragmentAddEntryBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentAddEntryBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val platforms = Constants.PLATFORMS
        val adapter = ArrayAdapter(requireContext(), android.R.layout.simple_dropdown_item_1line, platforms)
        binding.spinnerPlatform.setAdapter(adapter)
        binding.spinnerPlatform.setText(platforms[0], false)

        binding.etStartTime.setOnClickListener { showTimePicker(true) }
        binding.etEndTime.setOnClickListener { showTimePicker(false) }

        binding.btnSave.setOnClickListener { saveEntry() }
    }

    private fun showTimePicker(isStart: Boolean) {
        val cal = Calendar.getInstance()
        TimePickerDialog(
            requireContext(),
            { _, hour, minute ->
                val time = String.format("%02d:%02d", hour, minute)
                if (isStart) binding.etStartTime.setText(time)
                else binding.etEndTime.setText(time)
            },
            cal.get(Calendar.HOUR_OF_DAY),
            cal.get(Calendar.MINUTE),
            true
        ).show()
    }

    private fun saveEntry() {
        val platform = binding.spinnerPlatform.text.toString().trim()
        if (platform.isEmpty()) {
            Toast.makeText(requireContext(), "Platform seçin", Toast.LENGTH_SHORT).show()
            return
        }

        val earnings = binding.etEarnings.text.toString().toDoubleOrNull() ?: 0.0
        val tips = binding.etTips.text.toString().toDoubleOrNull() ?: 0.0
        val bonus = binding.etBonus.text.toString().toDoubleOrNull() ?: 0.0
        val expenses = binding.etExpenses.text.toString().toDoubleOrNull() ?: 0.0
        val start = binding.etStartTime.text.toString().trim()
        val end = binding.etEndTime.text.toString().trim()
        val note = binding.etNote.text.toString().trim()

        if (earnings == 0.0 && tips == 0.0 && bonus == 0.0) {
            Toast.makeText(requireContext(), "En az bir kazanç girin", Toast.LENGTH_SHORT).show()
            return
        }

        val hours = if (start.isNotEmpty() && end.isNotEmpty()) {
            DateUtils.calculateWorkHours(start, end)
        } else 0.0

        val entry = WorkEntry(
            platform = platform,
            earnings = earnings,
            tips = tips,
            bonus = bonus,
            expenses = expenses,
            startTime = start,
            endTime = end,
            workHours = hours,
            note = note,
            date = DateUtils.getStartOfDay()
        )

        lifecycleScope.launch {
            val repo = (requireActivity() as MainActivity).repository
            repo.insert(entry)
            Snackbar.make(binding.root, "Kayıt başarıyla eklendi", Snackbar.LENGTH_SHORT).show()
            clearForm()
        }
    }

    private fun clearForm() {
        binding.etEarnings.text?.clear()
        binding.etTips.text?.clear()
        binding.etBonus.text?.clear()
        binding.etExpenses.text?.clear()
        binding.etStartTime.text?.clear()
        binding.etEndTime.text?.clear()
        binding.etNote.text?.clear()
        binding.spinnerPlatform.setText(Constants.PLATFORMS[0], false)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
