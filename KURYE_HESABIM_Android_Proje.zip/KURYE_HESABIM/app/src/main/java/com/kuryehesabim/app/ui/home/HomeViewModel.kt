package com.kuryehesabim.app.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.kuryehesabim.app.data.WorkRepository
import com.kuryehesabim.app.data.entity.WorkEntry
import com.kuryehesabim.app.util.DateUtils
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class HomeUiState(
    val todayEarnings: Double = 0.0,
    val todayExpenses: Double = 0.0,
    val todayNet: Double = 0.0,
    val workHours: Double = 0.0,
    val hourlyRate: Double = 0.0,
    val recentEntries: List<WorkEntry> = emptyList()
)

class HomeViewModel(private val repository: WorkRepository) : ViewModel() {

    private val _uiState = MutableStateFlow(HomeUiState())
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            val start = DateUtils.getStartOfDay()
            val end = DateUtils.getEndOfDay()
            repository.getEntriesBetween(start, end + 1)
                .combine(repository.getAllEntries()) { today, all ->
                    Pair(today, all.take(10))
                }
                .collect { (todayEntries, recent) ->
                    val earnings = todayEntries.sumOf { it.earnings + it.tips + it.bonus }
                    val expenses = todayEntries.sumOf { it.expenses }
                    val net = earnings - expenses
                    val hours = todayEntries.sumOf { it.workHours }
                    val hourly = if (hours > 0) net / hours else 0.0
                    _uiState.value = HomeUiState(
                        todayEarnings = earnings,
                        todayExpenses = expenses,
                        todayNet = net,
                        workHours = hours,
                        hourlyRate = hourly,
                        recentEntries = recent
                    )
                }
        }
    }

    class Factory(private val repository: WorkRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return HomeViewModel(repository) as T
        }
    }
}
