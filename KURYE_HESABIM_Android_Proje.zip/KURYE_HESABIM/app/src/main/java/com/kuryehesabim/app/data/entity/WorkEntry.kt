package com.kuryehesabim.app.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "work_entries")
data class WorkEntry(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val platform: String,
    val earnings: Double = 0.0,
    val tips: Double = 0.0,
    val bonus: Double = 0.0,
    val expenses: Double = 0.0,
    val startTime: String = "",      // HH:mm
    val endTime: String = "",        // HH:mm
    val workHours: Double = 0.0,     // calculated
    val note: String = "",
    val date: Long = System.currentTimeMillis(), // epoch millis for day start
    val createdAt: Long = System.currentTimeMillis()
) {
    val net: Double
        get() = earnings + tips + bonus - expenses

    val hourlyNet: Double
        get() = if (workHours > 0) net / workHours else 0.0
}
