package com.kuryehesabim.app.util

object Constants {
    val PLATFORMS = listOf(
        "Trendyol Go",
        "Getir",
        "Yemeksepeti",
        "Migros Yemek",
        "HepsiJET",
        "Amazon",
        "Bağımsız Kurye"
    )

    fun getPlatformColor(platform: String): Int {
        return when (platform) {
            "Trendyol Go" -> 0xFFF27A1A.toInt()
            "Getir" -> 0xFF5D3EBC.toInt()
            "Yemeksepeti" -> 0xFFFA0050.toInt()
            "Migros Yemek" -> 0xFFFF6600.toInt()
            "HepsiJET" -> 0xFFFF6000.toInt()
            "Amazon" -> 0xFFFF9900.toInt()
            else -> 0xFF58A6FF.toInt()
        }
    }
}
