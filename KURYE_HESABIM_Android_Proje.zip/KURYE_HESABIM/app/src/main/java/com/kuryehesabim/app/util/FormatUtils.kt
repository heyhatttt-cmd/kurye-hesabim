package com.kuryehesabim.app.util

import java.text.NumberFormat
import java.util.*

object FormatUtils {
    private val currencyFormat = NumberFormat.getCurrencyInstance(Locale("tr", "TR")).apply {
        maximumFractionDigits = 2
        currency = Currency.getInstance("TRY")
    }

    private val numberFormat = NumberFormat.getNumberInstance(Locale("tr", "TR")).apply {
        maximumFractionDigits = 2
        minimumFractionDigits = 0
    }

    fun formatMoney(amount: Double): String {
        return String.format(Locale("tr"), "%.2f ₺", amount)
    }

    fun formatMoneySigned(amount: Double): String {
        val sign = if (amount >= 0) "+" else ""
        return sign + formatMoney(amount)
    }

    fun formatHours(hours: Double): String {
        return String.format(Locale("tr"), "%.1f saat", hours)
    }

    fun formatHourly(rate: Double): String {
        return String.format(Locale("tr"), "%.0f ₺/saat", rate)
    }
}
