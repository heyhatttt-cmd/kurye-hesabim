package com.kuryehesabim.app.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.kuryehesabim.app.data.entity.WorkEntry
import com.kuryehesabim.app.databinding.ItemEntryBinding
import com.kuryehesabim.app.util.Constants
import com.kuryehesabim.app.util.DateUtils
import com.kuryehesabim.app.util.FormatUtils

class EntryAdapter(
    private val onItemClick: ((WorkEntry) -> Unit)? = null
) : ListAdapter<WorkEntry, EntryAdapter.ViewHolder>(DiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemEntryBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class ViewHolder(private val binding: ItemEntryBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(entry: WorkEntry) {
            binding.tvPlatform.text = entry.platform
            binding.tvEntryDate.text = buildString {
                append(DateUtils.formatDate(entry.date))
                if (entry.startTime.isNotEmpty() && entry.endTime.isNotEmpty()) {
                    append(" • ")
                    append(entry.startTime)
                    append("-")
                    append(entry.endTime)
                }
            }
            binding.tvEntryNet.text = FormatUtils.formatMoneySigned(entry.net)
            binding.tvEntryDetails.text = buildString {
                append("Kazanç ${FormatUtils.formatMoney(entry.earnings)}")
                if (entry.tips > 0) append(" • Bahşiş ${FormatUtils.formatMoney(entry.tips)}")
                if (entry.bonus > 0) append(" • Prim ${FormatUtils.formatMoney(entry.bonus)}")
            }
            binding.viewPlatformColor.setBackgroundColor(Constants.getPlatformColor(entry.platform))

            binding.root.setOnClickListener { onItemClick?.invoke(entry) }
        }
    }

    class DiffCallback : DiffUtil.ItemCallback<WorkEntry>() {
        override fun areItemsTheSame(old: WorkEntry, new: WorkEntry) = old.id == new.id
        override fun areContentsTheSame(old: WorkEntry, new: WorkEntry) = old == new
    }
}
