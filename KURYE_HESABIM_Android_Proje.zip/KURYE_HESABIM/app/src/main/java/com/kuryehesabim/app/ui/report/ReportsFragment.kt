package com.kuryehesabim.app.ui.report

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import com.kuryehesabim.app.MainActivity
import com.kuryehesabim.app.databinding.FragmentReportsBinding
import com.kuryehesabim.app.ui.EntryAdapter
import com.kuryehesabim.app.util.FormatUtils
import kotlinx.coroutines.launch

class ReportsFragment : Fragment() {

    private var _binding: FragmentReportsBinding? = null
    private val binding get() = _binding!!

    private val viewModel: ReportsViewModel by viewModels {
        ReportsViewModel.Factory((requireActivity() as MainActivity).repository)
    }

    private lateinit var adapter: EntryAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentReportsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        adapter = EntryAdapter()
        binding.rvReportEntries.layoutManager = LinearLayoutManager(requireContext())
        binding.rvReportEntries.adapter = adapter

        binding.togglePeriod.check(binding.btnDaily.id)
        binding.togglePeriod.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (isChecked) {
                when (checkedId) {
                    binding.btnDaily.id -> viewModel.setPeriod(ReportPeriod.DAILY)
                    binding.btnWeekly.id -> viewModel.setPeriod(ReportPeriod.WEEKLY)
                    binding.btnMonthly.id -> viewModel.setPeriod(ReportPeriod.MONTHLY)
                }
            }
        }

        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.uiState.collect { state ->
                    binding.tvReportEarnings.text = FormatUtils.formatMoney(state.totalEarnings)
                    binding.tvReportTips.text = FormatUtils.formatMoney(state.totalTips)
                    binding.tvReportBonus.text = FormatUtils.formatMoney(state.totalBonus)
                    binding.tvReportExpenses.text = FormatUtils.formatMoney(state.totalExpenses)
                    binding.tvReportNet.text = FormatUtils.formatMoney(state.net)
                    binding.tvReportHours.text = FormatUtils.formatHours(state.totalHours)
                    binding.tvReportHourly.text = FormatUtils.formatHourly(state.avgHourly)
                    adapter.submitList(state.entries)
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
