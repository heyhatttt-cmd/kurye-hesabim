package com.kuryehesabim.app.ui.home

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import com.kuryehesabim.app.MainActivity
import com.kuryehesabim.app.databinding.FragmentHomeBinding
import com.kuryehesabim.app.ui.EntryAdapter
import com.kuryehesabim.app.util.DateUtils
import com.kuryehesabim.app.util.FormatUtils
import kotlinx.coroutines.launch

class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!

    private val viewModel: HomeViewModel by viewModels {
        HomeViewModel.Factory((requireActivity() as MainActivity).repository)
    }

    private lateinit var adapter: EntryAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.tvDateHeader.text = DateUtils.formatFullDate(System.currentTimeMillis())

        adapter = EntryAdapter()
        binding.rvRecentEntries.layoutManager = LinearLayoutManager(requireContext())
        binding.rvRecentEntries.adapter = adapter

        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.uiState.collect { state ->
                    binding.tvTodayEarnings.text = FormatUtils.formatMoney(state.todayEarnings)
                    binding.tvTodayExpenses.text = FormatUtils.formatMoney(state.todayExpenses)
                    binding.tvTodayNet.text = FormatUtils.formatMoney(state.todayNet)
                    binding.tvWorkHours.text = FormatUtils.formatHours(state.workHours)
                    binding.tvHourlyRate.text = FormatUtils.formatHourly(state.hourlyRate)

                    adapter.submitList(state.recentEntries)
                    binding.tvEmpty.visibility =
                        if (state.recentEntries.isEmpty()) View.VISIBLE else View.GONE
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
