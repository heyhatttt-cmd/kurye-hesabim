package com.kuryehesabim.app.ui.report

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.kuryehesabim.app.data.WorkRepository
import com.kuryehesabim.app.data.entity.WorkEntry
import com.kuryehesabim.app.util.DateUtils
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

enum class ReportPeriod { DAILY, WEEKLY, MONTHLY }

data class ReportUiState(
    val period: ReportPeriod = ReportPeriod.DAILY,
    val totalEarnings: Double = 0.0,
    val totalTips: Double = 0.0,
    val totalBonus: Double = 0.0,
    val totalExpenses: Double = 0.0,
    val net: Double = 0.0,
    val totalHours: Double = 0.0,
    val avgHourly: Double = 0.0,
    val entries: List<WorkEntry> = emptyList()
)

class ReportsViewModel(private val repository: WorkRepository) : ViewModel() {

    private val _period = MutableStateFlow(ReportPeriod.DAILY)
    private val _uiState = MutableStateFlow(ReportUiState())
    val uiState: StateFlow<ReportUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            _period.collect { period ->
                val (start, end) = when (period) {
                    ReportPeriod.DAILY -> DateUtils.getStartOfDay() to DateUtils.getEndOfDay()
                    ReportPeriod.WEEKLY -> DateUtils.getStartOfWeek() to System.currentTimeMillis()
                    ReportPeriod.MONTHLY -> DateUtils.getStartOfMonth() to System.currentTimeMillis()
                }
                repository.getEntriesBetween(start, end + 1).collect { entries ->
                    val earnings = entries.sumOf { it.earnings }
                    val tips = entries.sumOf { it.tips }
                    val bonus = entries.sumOf { it.bonus }
                    val expenses = entries.sumOf { it.expenses }
                    val net = earnings + tips + bonus - expenses
                    val hours = entries.sumOf { it.workHours }
                    val hourly = if (hours > 0) net / hours else 0.0
                    _uiState.value = ReportUiState(
                        period = period,
                        totalEarnings = earnings,
                        totalTips = tips,
                        totalBonus = bonus,
                        totalExpenses = expenses,
                        net = net,
                        totalHours = hours,
                        avgHourly = hourly,
                        entries = entries
                    )
                }
            }
        }
    }

    fun setPeriod(period: ReportPeriod) {
        _period.value = period
    }

    class Factory(private val repository: WorkRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return ReportsViewModel(repository) as T
        }
    }
}
