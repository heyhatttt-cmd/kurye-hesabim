# KURYE HESABIM

Profesyonel Android uygulaması — Kurye kazanç, gider, bahşiş ve prim takibi.

## Özellikler

- **Günlük kazanç ve gider takibi**
- **Bahşiş ve prim kaydı**
- **Çalışma saati ve saatlik net kazanç hesabı**
- Desteklenen platformlar:
  - Trendyol Go
  - Getir
  - Yemeksepeti
  - Migros Yemek
  - HepsiJET
  - Amazon
  - Bağımsız Kurye
- **Günlük, haftalık ve aylık raporlar**
- Modern koyu tema
- Türkçe arayüz
- Yerel veritabanı (Room) — hesap sistemi için genişletilebilir altyapı

## Teknik Bilgiler

- **Dil:** Kotlin
- **Min SDK:** 24 (Android 7.0)
- **Target SDK:** 34
- **Mimari:** MVVM + Repository + Room + Flow
- **UI:** Material Design 3, View Binding, Navigation Component

## Kurulum (Android Studio)

1. Bu projeyi klonlayın veya ZIP olarak indirin.
2. Android Studio'da **File → Open** ile proje klasörünü açın.
3. Gradle senkronizasyonunu bekleyin.
4. Emülatör veya fiziksel cihazda **Run** edin.

### Gradle Wrapper

Projede `gradlew` bulunmuyorsa Android Studio otomatik oluşturur. Manuel için:

```bash
gradle wrapper --gradle-version 8.2
```

## APK Oluşturma (GitHub Actions)

`.github/workflows/build-apk.yml` dosyası push ve pull request'lerde otomatik debug APK üretir.

Manuel tetikleme: GitHub → Actions → Build APK → Run workflow

APK artifact olarak indirilebilir.

## Yerel APK Build

```bash
./gradlew assembleDebug
# APK: app/build/outputs/apk/debug/app-debug.apk
```

Release için:

```bash
./gradlew assembleRelease
```

## Proje Yapısı

```
app/
├── src/main/
│   ├── java/com/kuryehesabim/app/
│   │   ├── data/          # Room entity, DAO, Database, Repository
│   │   ├── ui/            # Fragments, ViewModels, Adapter
│   │   ├── util/          # Yardımcı sınıflar
│   │   └── MainActivity.kt
│   ├── res/               # Layouts, values, drawable, navigation
│   └── AndroidManifest.xml
├── build.gradle.kts
└── ...
```

## Geliştirme Notları

- Hesap sistemi (login/register) için altyapı hazırdır; Settings ekranı placeholder içerir.
- MPAndroidChart bağımlılığı eklendi (gelecek grafik özellikleri için).
- Veriler cihaz üzerinde Room veritabanında saklanır.

## Lisans

Bu proje eğitim ve kişisel kullanım amaçlıdır.

---

**KURYE HESABIM** — Kuryelerin kazanç takibi için tasarlandı.
