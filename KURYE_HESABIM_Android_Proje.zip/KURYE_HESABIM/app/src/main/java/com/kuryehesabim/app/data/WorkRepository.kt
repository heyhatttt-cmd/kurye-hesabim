package com.kuryehesabim.app.data

import com.kuryehesabim.app.data.dao.WorkEntryDao
import com.kuryehesabim.app.data.entity.WorkEntry
import kotlinx.coroutines.flow.Flow

class WorkRepository(private val dao: WorkEntryDao) {

    fun getAllEntries(): Flow<List<WorkEntry>> = dao.getAllEntries()

    fun getEntriesBetween(start: Long, end: Long): Flow<List<WorkEntry>> =
        dao.getEntriesBetween(start, end)

    suspend fun insert(entry: WorkEntry): Long = dao.insert(entry)

    suspend fun update(entry: WorkEntry) = dao.update(entry)

    suspend fun delete(entry: WorkEntry) = dao.delete(entry)

    suspend fun getById(id: Long) = dao.getEntryById(id)
}
