package com.kuryehesabim.app.data.dao

import androidx.room.*
import com.kuryehesabim.app.data.entity.WorkEntry
import kotlinx.coroutines.flow.Flow

@Dao
interface WorkEntryDao {

    @Query("SELECT * FROM work_entries ORDER BY date DESC, createdAt DESC")
    fun getAllEntries(): Flow<List<WorkEntry>>

    @Query("SELECT * FROM work_entries WHERE date >= :start AND date < :end ORDER BY date DESC")
    fun getEntriesBetween(start: Long, end: Long): Flow<List<WorkEntry>>

    @Query("SELECT * FROM work_entries WHERE id = :id")
    suspend fun getEntryById(id: Long): WorkEntry?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(entry: WorkEntry): Long

    @Update
    suspend fun update(entry: WorkEntry)

    @Delete
    suspend fun delete(entry: WorkEntry)

    @Query("DELETE FROM work_entries WHERE id = :id")
    suspend fun deleteById(id: Long)
}
